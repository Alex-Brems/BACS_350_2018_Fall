<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <title>
            <?php
                echo $page_title;
            ?>

        </title>
        <link rel="stylesheet" href="style.css">

    </head>
    <body>

        <header>
            <h1>
                <?php
                    echo $page_title;
                ?>
            </h1>
        </header>
        <main>
            <p>Remove this placeholder text...</p>
