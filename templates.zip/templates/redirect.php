<?php

// Jump to a different page
header('Location: error.php');

// Go to the current directory
// header('Location: .');

// Go to the Google
// header('Location: http://google.com');

?>